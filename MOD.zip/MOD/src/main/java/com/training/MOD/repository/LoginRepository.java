package com.training.MOD.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.training.MOD.models.login;


@Repository
public interface LoginRepository extends JpaRepository<login, Integer>{

	//login findByEmail(String email);
	
	
	@Query("SELECT u FROM login u WHERE u.email = :email and u.password = :pass")
    public login findUser(@Param("email") String email,@Param("pass") String pass);
	
	
}
