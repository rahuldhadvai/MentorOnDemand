package com.training.MOD.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.training.MOD.models.login;
import com.training.MOD.repository.LoginRepository;

@Component
public class UserService {

	@Autowired
	LoginRepository loginRepository;
	
	public login findUserService(String email,String password)
	{
		return loginRepository.findUser(email, password);
	}
}
